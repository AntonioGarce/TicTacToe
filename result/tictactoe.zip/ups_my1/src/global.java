public class global {
    public static Network network = new Network();
    public static String nickName = new String();
    public static Form mainForm = new Form();
    public static int numLobby = 0;
    public static int numRoom = 0;
    public static int lobby = 1;
    public static int room = 1;
    public static boolean inRoom = false;
    public static boolean isLoggedIn = false;
}