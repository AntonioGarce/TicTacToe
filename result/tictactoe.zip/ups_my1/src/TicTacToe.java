public class TicTacToe implements Runnable {
    public TicTacToe() {
        global.mainForm.setVisible(true);
    }

    @Override
    public void run() {
        
    }
}
