/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chess_game.Resources;


/**
 *
 * @author Enes Kızılcın <nazifenes.kizilcin@stu.fsm.edu.tr>
 */
public class BOARD_Configurations {

    public static int ROW_COUNT = 8;
    public static int ROW_TILE_COUNT = 8;
    public static int BOARD_LOWER_BOUND = 0;
    public static int BOARD_UPPER_BOUND = 7;
    public static int TILE_SIZE = 60;
    
}
