package lecture32;

public class Client {

	public static void main(String[] args) {
		TTT obj = new TTT();
	}

}
