package com.ggl.tictactoe.model;

public enum GameStatus {
		ACTIVE_GAME, TIE_GAME, COMPUTER_WINS, PLAYER_WINS
}
