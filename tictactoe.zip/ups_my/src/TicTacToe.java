public class TicTacToe implements Runnable {

    public TicTacToe() {
        Form settings = new Form();
        Network network = new Network();
    }

    @Override
    public void run() {

    }
}
